from django.shortcuts import render, HttpResponse
from .models import Department, Student, Course


def index(request):
    depts = Department.objects.annotate()

    return render(request, 'index.html', {"depts":depts})

def courses(request):
    courses = Course.objects.all()
    
    return render(request, 'courses.html', {"courses":courses})